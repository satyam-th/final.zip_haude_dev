# Java Project – haude_dev Group

Welcome to the **haude_dev** group's Java project! This repository contains the source code and documentation for our collaborative Snake and Ladder game built with Java Swing.

## Project Overview
> A turn-based Snake and Ladder game featuring player statistics, game state saving, and a clean graphical user interface.

## Technologies Used
- Java Swing
- Git & GitHub

## Project Structure
- `player.java`
- `dice.java`
- `board.java` (error fixes applied on Day 3)
- Code cleanup tasks
- Game log function to be added to `gameinstance`
- All major features complete

## How to Run
1. Ensure JDK is installed on your system.
2. Clone this repository.
3. Open the project in your preferred IDE.
4. Open `startmain.java`.
5. Run `startmain.java` to start the game.

